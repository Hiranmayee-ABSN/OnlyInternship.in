import { Link } from 'wouter';
import { MapPin, Clock, DollarSign, Calendar, Code } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { InternshipWithDetails, getTypeColor, getTypeText } from '@/lib/types';

interface InternshipCardProps {
  internship: InternshipWithDetails;
  className?: string;
}

export default function InternshipCard({ internship, className = '' }: InternshipCardProps) {
  const formatStipend = (min?: string, max?: string) => {
    if (!min && !max) return 'Stipend not specified';
    if (min && max) return `₹${min} - ₹${max}/month`;
    if (min) return `₹${min}/month`;
    return `₹${max}/month`;
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  return (
    <Card className={`hover:shadow-lg transition-shadow duration-200 ${className}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center">
            <div className="company-logo mr-3">
              <Code className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 text-lg">{internship.title}</h3>
              <p className="text-sm text-gray-600">{internship.company.name}</p>
            </div>
          </div>
          <Badge className={getTypeColor(internship.type)}>
            {getTypeText(internship.type)}
          </Badge>
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex items-center text-sm text-gray-600">
            <MapPin className="h-4 w-4 mr-2" />
            <span>{internship.location}</span>
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <Clock className="h-4 w-4 mr-2" />
            <span>{internship.duration}</span>
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <DollarSign className="h-4 w-4 mr-2" />
            <span>{formatStipend(internship.stipendMin, internship.stipendMax)}</span>
          </div>
        </div>

        {internship.skills && internship.skills.length > 0 && (
          <div className="mb-4">
            <div className="flex flex-wrap gap-2">
              {internship.skills.slice(0, 3).map((skill, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {skill}
                </Badge>
              ))}
              {internship.skills.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{internship.skills.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        <div className="flex justify-between items-center">
          <div className="flex items-center text-sm text-gray-500">
            <Calendar className="h-4 w-4 mr-1" />
            <span>Posted {formatDate(internship.createdAt)}</span>
          </div>
          <Link href={`/internships/${internship.id}`}>
            <Button>
              Apply Now
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
