import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/lib/auth';
import { InternshipWithDetails } from '@/lib/types';

const applicationSchema = z.object({
  coverLetter: z.string().min(10, 'Cover letter must be at least 10 characters'),
  resume: z.string().url('Please provide a valid URL for your resume').optional(),
});

type ApplicationFormData = z.infer<typeof applicationSchema>;

interface ApplicationFormProps {
  internship: InternshipWithDetails;
  onSuccess?: () => void;
}

export default function ApplicationForm({ internship, onSuccess }: ApplicationFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ApplicationFormData>({
    resolver: zodResolver(applicationSchema),
    defaultValues: {
      coverLetter: '',
      resume: '',
    },
  });

  const applicationMutation = useMutation({
    mutationFn: async (data: ApplicationFormData) => {
      const response = await apiRequest('POST', '/api/applications', {
        internshipId: internship.id,
        coverLetter: data.coverLetter,
        resume: data.resume,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Application submitted successfully!',
        description: 'We will notify you about the status of your application.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/applications'] });
      onSuccess?.();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error submitting application',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const onSubmit = async (data: ApplicationFormData) => {
    if (!user) {
      toast({
        title: 'Authentication required',
        description: 'Please login to apply for internships.',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await applicationMutation.mutateAsync(data);
      form.reset();
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-center text-gray-600">
            Please login to apply for this internship.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (user.role !== 'student') {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-center text-gray-600">
            Only students can apply for internships.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Apply for {internship.title}</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="coverLetter"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cover Letter</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Tell us why you're interested in this internship and what makes you a good fit..."
                      className="min-h-[120px]"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="resume"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Resume URL (Optional)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="https://drive.google.com/file/d/your-resume-id/view"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="w-full" 
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Submitting...' : 'Submit Application'}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
