import { User, Company, Internship, StudentProfile, Application } from "@shared/schema";

export interface AuthUser {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  role: 'student' | 'recruiter' | 'admin';
}

export interface InternshipWithDetails extends Internship {
  company: Company;
  recruiter: User;
}

export interface ApplicationWithDetails extends Application {
  student: User;
  internship: InternshipWithDetails;
}

export interface StudentApplicationWithDetails extends Application {
  internship: InternshipWithDetails;
}

export interface RecruiterApplicationWithDetails extends Application {
  student: User;
}

export interface InternshipFilters {
  search?: string;
  domain?: string;
  location?: string;
  type?: string;
  duration?: string;
  limit?: number;
  offset?: number;
}

export interface ApiResponse<T> {
  data?: T;
  message?: string;
  error?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface StatsData {
  totalUsers: number;
  totalInternships: number;
  totalCompanies: number;
  totalApplications: number;
}

export interface DashboardStats {
  applications?: number;
  interviews?: number;
  saved?: number;
  profileViews?: number;
  activePostings?: number;
  hired?: number;
}

export const DOMAINS = [
  'Technology',
  'Marketing',
  'Finance',
  'Design',
  'Sales',
  'Operations',
  'HR',
  'Content',
  'Research',
  'Other'
];

export const LOCATIONS = [
  'Remote',
  'Mumbai',
  'Bangalore',
  'Delhi',
  'Pune',
  'Hyderabad',
  'Chennai',
  'Kolkata',
  'Ahmedabad',
  'Gurgaon',
  'Other'
];

export const DURATIONS = [
  '1-3 months',
  '3-6 months',
  '6+ months'
];

export const INTERNSHIP_TYPES = [
  'remote',
  'on-site',
  'hybrid'
];

export const APPLICATION_STATUSES = [
  'pending',
  'under_review',
  'interview_scheduled',
  'accepted',
  'rejected'
];

export const getStatusColor = (status: string) => {
  switch (status) {
    case 'pending':
      return 'bg-yellow-100 text-yellow-800';
    case 'under_review':
      return 'bg-blue-100 text-blue-800';
    case 'interview_scheduled':
      return 'bg-green-100 text-green-800';
    case 'accepted':
      return 'bg-green-100 text-green-800';
    case 'rejected':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export const getStatusText = (status: string) => {
  switch (status) {
    case 'pending':
      return 'Pending';
    case 'under_review':
      return 'Under Review';
    case 'interview_scheduled':
      return 'Interview Scheduled';
    case 'accepted':
      return 'Accepted';
    case 'rejected':
      return 'Rejected';
    default:
      return status;
  }
};

export const getTypeColor = (type: string) => {
  switch (type) {
    case 'remote':
      return 'bg-secondary text-white';
    case 'on-site':
      return 'bg-primary text-white';
    case 'hybrid':
      return 'bg-accent text-white';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export const getTypeText = (type: string) => {
  switch (type) {
    case 'remote':
      return 'Remote';
    case 'on-site':
      return 'On-site';
    case 'hybrid':
      return 'Hybrid';
    default:
      return type;
  }
};
