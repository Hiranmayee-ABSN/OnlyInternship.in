import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Building, 
  Plus, 
  Users, 
  FileText,
  BarChart,
  Briefcase,
  UserCheck,
  Eye,
  MapPin,
  Clock,
  DollarSign,
  Calendar,
  CheckCircle,
  X,
  Edit,
  Trash2
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/auth';
import { apiRequest } from '@/lib/queryClient';
import { getAuthHeaders } from '@/lib/auth';
import { 
  InternshipWithDetails, 
  RecruiterApplicationWithDetails,
  getStatusColor, 
  getStatusText,
  DOMAINS,
  LOCATIONS,
  DURATIONS,
  INTERNSHIP_TYPES
} from '@/lib/types';
import { Link } from 'wouter';

const internshipSchema = z.object({
  title: z.string().min(2, 'Title must be at least 2 characters'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  requirements: z.string().min(10, 'Requirements must be at least 10 characters'),
  companyId: z.number().min(1, 'Please select a company'),
  location: z.string().min(2, 'Location is required'),
  type: z.enum(['remote', 'on-site', 'hybrid']),
  duration: z.string().min(1, 'Duration is required'),
  stipendMin: z.string().optional(),
  stipendMax: z.string().optional(),
  skills: z.string().optional(),
  domain: z.string().min(1, 'Domain is required'),
});

type InternshipFormData = z.infer<typeof internshipSchema>;

export default function RecruiterDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('overview');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingInternship, setEditingInternship] = useState<InternshipWithDetails | null>(null);

  // Fetch companies
  const { data: companies } = useQuery({
    queryKey: ['/api/companies'],
    queryFn: async () => {
      const response = await fetch('/api/companies');
      if (!response.ok) throw new Error('Failed to fetch companies');
      return response.json();
    },
  });

  // Fetch recruiter's internships
  const { data: internships, isLoading: internshipsLoading } = useQuery({
    queryKey: ['/api/internships/recruiter', user?.id],
    queryFn: async () => {
      const response = await fetch(`/api/internships/recruiter/${user?.id}`, {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error('Failed to fetch internships');
      return response.json();
    },
    enabled: !!user && user.role === 'recruiter',
  });

  // Fetch applications for recruiter's internships
  const { data: applications, isLoading: applicationsLoading } = useQuery({
    queryKey: ['/api/applications', 'recruiter'],
    queryFn: async () => {
      if (!internships || internships.length === 0) return [];
      
      const allApplications = await Promise.all(
        internships.map(async (internship: InternshipWithDetails) => {
          const response = await fetch(`/api/applications/internship/${internship.id}`, {
            headers: getAuthHeaders(),
          });
          if (!response.ok) return [];
          const apps = await response.json();
          return apps.map((app: any) => ({ ...app, internship }));
        })
      );
      
      return allApplications.flat();
    },
    enabled: !!internships && internships.length > 0,
  });

  const form = useForm<InternshipFormData>({
    resolver: zodResolver(internshipSchema),
    defaultValues: {
      title: '',
      description: '',
      requirements: '',
      companyId: 0,
      location: '',
      type: 'remote',
      duration: '',
      stipendMin: '',
      stipendMax: '',
      skills: '',
      domain: '',
    },
  });

  const internshipMutation = useMutation({
    mutationFn: async (data: InternshipFormData) => {
      const internshipData = {
        ...data,
        skills: data.skills ? data.skills.split(',').map(s => s.trim()).filter(Boolean) : [],
        stipendMin: data.stipendMin || null,
        stipendMax: data.stipendMax || null,
      };

      const method = editingInternship ? 'PUT' : 'POST';
      const url = editingInternship ? `/api/internships/${editingInternship.id}` : '/api/internships';
      
      const response = await apiRequest(method, url, internshipData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: editingInternship ? 'Internship updated!' : 'Internship created!',
        description: editingInternship 
          ? 'Your internship has been updated successfully.' 
          : 'Your internship has been posted successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/internships/recruiter'] });
      setIsCreateDialogOpen(false);
      setEditingInternship(null);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteInternshipMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/internships/${id}`);
    },
    onSuccess: () => {
      toast({
        title: 'Internship deleted',
        description: 'The internship has been removed successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/internships/recruiter'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error deleting internship',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const updateApplicationMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const response = await apiRequest('PUT', `/api/applications/${id}`, { status });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Application updated',
        description: 'The application status has been updated.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/applications'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error updating application',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: InternshipFormData) => {
    internshipMutation.mutate(data);
  };

  const handleEdit = (internship: InternshipWithDetails) => {
    setEditingInternship(internship);
    form.reset({
      title: internship.title,
      description: internship.description,
      requirements: internship.requirements,
      companyId: internship.companyId,
      location: internship.location,
      type: internship.type,
      duration: internship.duration,
      stipendMin: internship.stipendMin || '',
      stipendMax: internship.stipendMax || '',
      skills: internship.skills?.join(', ') || '',
      domain: internship.domain,
    });
    setIsCreateDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this internship?')) {
      deleteInternshipMutation.mutate(id);
    }
  };

  const handleApplicationAction = (applicationId: number, action: string) => {
    updateApplicationMutation.mutate({ id: applicationId, status: action });
  };

  if (!user || user.role !== 'recruiter') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-red-600">Access denied. Recruiter account required.</p>
            <Link href="/">
              <Button className="mt-4">Go Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const stats = {
    activePostings: internships?.filter((i: any) => i.isActive).length || 0,
    totalApplications: applications?.length || 0,
    interviews: applications?.filter((a: any) => a.status === 'interview_scheduled').length || 0,
    hired: applications?.filter((a: any) => a.status === 'accepted').length || 0,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Recruiter Dashboard</h1>
          <p className="text-gray-600">Manage your internship postings and applications</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <Avatar className="w-20 h-20 mx-auto mb-3">
                    <AvatarFallback className="text-2xl">
                      <Building className="h-8 w-8" />
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="font-semibold text-gray-900">{user.firstName} {user.lastName}</h3>
                  <p className="text-sm text-gray-600">Recruiter</p>
                </div>
                
                <nav className="space-y-2">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'overview' 
                        ? 'bg-secondary text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <BarChart className="h-4 w-4 mr-3" />
                    Dashboard
                  </button>
                  <button
                    onClick={() => setActiveTab('internships')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'internships' 
                        ? 'bg-secondary text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Briefcase className="h-4 w-4 mr-3" />
                    My Postings
                  </button>
                  <button
                    onClick={() => setActiveTab('applications')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'applications' 
                        ? 'bg-secondary text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Users className="h-4 w-4 mr-3" />
                    Applicants
                  </button>
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center mr-3">
                          <Briefcase className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Active Postings</p>
                          <p className="text-2xl font-bold text-gray-900">{stats.activePostings}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center mr-3">
                          <FileText className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Applications</p>
                          <p className="text-2xl font-bold text-gray-900">{stats.totalApplications}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center mr-3">
                          <Calendar className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Interviews</p>
                          <p className="text-2xl font-bold text-gray-900">{stats.interviews}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center mr-3">
                          <UserCheck className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Hired</p>
                          <p className="text-2xl font-bold text-gray-900">{stats.hired}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Button 
                        className="h-20 bg-secondary hover:bg-secondary/90" 
                        onClick={() => setIsCreateDialogOpen(true)}
                      >
                        <div className="text-center">
                          <Plus className="h-6 w-6 mx-auto mb-2" />
                          <div>Post New Internship</div>
                        </div>
                      </Button>
                      <Button 
                        variant="outline" 
                        className="h-20"
                        onClick={() => setActiveTab('applications')}
                      >
                        <div className="text-center">
                          <Users className="h-6 w-6 mx-auto mb-2" />
                          <div>Review Applications</div>
                        </div>
                      </Button>
                      <Button 
                        variant="outline" 
                        className="h-20"
                        onClick={() => setActiveTab('internships')}
                      >
                        <div className="text-center">
                          <BarChart className="h-6 w-6 mx-auto mb-2" />
                          <div>View Analytics</div>
                        </div>
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Applications */}
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Applications</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {applicationsLoading ? (
                      <div className="text-center py-4">
                        <div className="loading-spinner mx-auto mb-2"></div>
                        <p className="text-gray-600">Loading applications...</p>
                      </div>
                    ) : applications && applications.length > 0 ? (
                      <div className="space-y-4">
                        {applications.slice(0, 5).map((application: RecruiterApplicationWithDetails) => (
                          <div key={application.id} className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center">
                              <Avatar className="mr-3">
                                <AvatarFallback>
                                  {application.student.firstName[0]}{application.student.lastName[0]}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <h4 className="font-medium text-gray-900">
                                  {application.student.firstName} {application.student.lastName}
                                </h4>
                                <p className="text-sm text-gray-600">{application.internship.title}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge className={getStatusColor(application.status)}>
                                {getStatusText(application.status)}
                              </Badge>
                              {application.status === 'pending' && (
                                <div className="flex space-x-2">
                                  <Button
                                    size="sm"
                                    onClick={() => handleApplicationAction(application.id, 'interview_scheduled')}
                                  >
                                    Interview
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => handleApplicationAction(application.id, 'rejected')}
                                  >
                                    Reject
                                  </Button>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600">No applications yet</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'internships' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">My Internships</h2>
                  <Button onClick={() => setIsCreateDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Post Internship
                  </Button>
                </div>

                {internshipsLoading ? (
                  <div className="text-center py-8">
                    <div className="loading-spinner mx-auto mb-4"></div>
                    <p className="text-gray-600">Loading internships...</p>
                  </div>
                ) : internships && internships.length > 0 ? (
                  <div className="space-y-4">
                    {internships.map((internship: InternshipWithDetails) => (
                      <Card key={internship.id}>
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div>
                              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                                {internship.title}
                              </h3>
                              <p className="text-gray-600 mb-2">{internship.company.name}</p>
                              <div className="flex items-center space-x-4 text-sm text-gray-500">
                                <span className="flex items-center">
                                  <MapPin className="h-4 w-4 mr-1" />
                                  {internship.location}
                                </span>
                                <span className="flex items-center">
                                  <Clock className="h-4 w-4 mr-1" />
                                  {internship.duration}
                                </span>
                                <span className="flex items-center">
                                  <Calendar className="h-4 w-4 mr-1" />
                                  {new Date(internship.createdAt).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge variant={internship.isActive ? 'default' : 'secondary'}>
                                {internship.isActive ? 'Active' : 'Inactive'}
                              </Badge>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleEdit(internship)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleDelete(internship.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                          
                          <p className="text-gray-700 mb-4 line-clamp-2">
                            {internship.description}
                          </p>
                          
                          <div className="flex justify-between items-center">
                            <div>
                              {internship.skills && internship.skills.length > 0 && (
                                <div className="flex flex-wrap gap-1">
                                  {internship.skills.slice(0, 3).map((skill, index) => (
                                    <Badge key={index} variant="secondary" className="text-xs">
                                      {skill}
                                    </Badge>
                                  ))}
                                  {internship.skills.length > 3 && (
                                    <Badge variant="outline" className="text-xs">
                                      +{internship.skills.length - 3}
                                    </Badge>
                                  )}
                                </div>
                              )}
                            </div>
                            <div className="text-right">
                              <p className="text-sm text-gray-500">
                                {applications?.filter((a: any) => a.internship?.id === internship.id).length || 0} applications
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Briefcase className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-4">No internships posted yet</p>
                    <Button onClick={() => setIsCreateDialogOpen(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Post Your First Internship
                    </Button>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'applications' && (
              <Card>
                <CardHeader>
                  <CardTitle>All Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  {applicationsLoading ? (
                    <div className="text-center py-8">
                      <div className="loading-spinner mx-auto mb-4"></div>
                      <p className="text-gray-600">Loading applications...</p>
                    </div>
                  ) : applications && applications.length > 0 ? (
                    <div className="space-y-4">
                      {applications.map((application: RecruiterApplicationWithDetails) => (
                        <div key={application.id} className="border rounded-lg p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex items-center">
                              <Avatar className="mr-4">
                                <AvatarFallback>
                                  {application.student.firstName[0]}{application.student.lastName[0]}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <h3 className="font-semibold text-gray-900">
                                  {application.student.firstName} {application.student.lastName}
                                </h3>
                                <p className="text-gray-600">{application.student.email}</p>
                                <p className="text-sm text-gray-500">
                                  Applied for: {application.internship.title}
                                </p>
                              </div>
                            </div>
                            <Badge className={getStatusColor(application.status)}>
                              {getStatusText(application.status)}
                            </Badge>
                          </div>

                          {application.coverLetter && (
                            <div className="mb-4">
                              <p className="text-sm font-medium text-gray-700 mb-2">Cover Letter:</p>
                              <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
                                {application.coverLetter}
                              </p>
                            </div>
                          )}

                          <div className="flex justify-between items-center">
                            <div className="flex space-x-2">
                              {application.resume && (
                                <a 
                                  href={application.resume} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                >
                                  <Button variant="outline" size="sm">
                                    <Eye className="h-4 w-4 mr-1" />
                                    View Resume
                                  </Button>
                                </a>
                              )}
                            </div>
                            
                            {application.status === 'pending' && (
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  className="bg-secondary hover:bg-secondary/90"
                                  onClick={() => handleApplicationAction(application.id, 'interview_scheduled')}
                                >
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Schedule Interview
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleApplicationAction(application.id, 'rejected')}
                                >
                                  <X className="h-4 w-4 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            )}
                            
                            {application.status === 'interview_scheduled' && (
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700"
                                  onClick={() => handleApplicationAction(application.id, 'accepted')}
                                >
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Accept
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleApplicationAction(application.id, 'rejected')}
                                >
                                  <X className="h-4 w-4 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 mb-4">No applications yet</p>
                      <p className="text-gray-500">Applications will appear here once students apply to your internships</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Create/Edit Internship Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingInternship ? 'Edit Internship' : 'Post New Internship'}
              </DialogTitle>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Job Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Frontend Developer Intern" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="companyId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))} 
                        defaultValue={field.value?.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a company" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {companies?.map((company: any) => (
                            <SelectItem key={company.id} value={company.id.toString()}>
                              {company.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="domain"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Domain</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select domain" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {DOMAINS.map((domain) => (
                              <SelectItem key={domain} value={domain}>
                                {domain}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Work Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {INTERNSHIP_TYPES.map((type) => (
                              <SelectItem key={type} value={type}>
                                {type.charAt(0).toUpperCase() + type.slice(1)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location</FormLabel>
                        <FormControl>
                          <Input placeholder="Mumbai, India" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="duration"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Duration</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select duration" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {DURATIONS.map((duration) => (
                              <SelectItem key={duration} value={duration}>
                                {duration}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="stipendMin"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Minimum Stipend (₹)</FormLabel>
                        <FormControl>
                          <Input placeholder="15000" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="stipendMax"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Maximum Stipend (₹)</FormLabel>
                        <FormControl>
                          <Input placeholder="25000" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="skills"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Required Skills (comma-separated)</FormLabel>
                      <FormControl>
                        <Input placeholder="React, JavaScript, HTML, CSS" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Job Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe the internship role, responsibilities, and what the intern will learn..."
                          className="min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="requirements"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Requirements & Qualifications</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="List the requirements, qualifications, and preferred skills..."
                          className="min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex space-x-4">
                  <Button
                    type="submit"
                    disabled={internshipMutation.isPending}
                    className="flex-1"
                  >
                    {internshipMutation.isPending 
                      ? (editingInternship ? 'Updating...' : 'Posting...') 
                      : (editingInternship ? 'Update Internship' : 'Post Internship')
                    }
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsCreateDialogOpen(false);
                      setEditingInternship(null);
                      form.reset();
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
