import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarInitials } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { 
  User, 
  FileText, 
  Heart, 
  Settings, 
  NotebookPen, 
  CheckCircle, 
  Clock, 
  X,
  Eye,
  Calendar,
  MapPin,
  DollarSign,
  Building
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/auth';
import { apiRequest } from '@/lib/queryClient';
import { getAuthHeaders } from '@/lib/auth';
import { StudentApplicationWithDetails, getStatusColor, getStatusText } from '@/lib/types';
import { Link } from 'wouter';

const profileSchema = z.object({
  bio: z.string().optional(),
  skills: z.string().optional(),
  interests: z.string().optional(),
  education: z.string().optional(),
  experience: z.string().optional(),
  portfolio: z.string().url('Please enter a valid URL').optional().or(z.literal('')),
  resume: z.string().url('Please enter a valid URL').optional().or(z.literal('')),
});

type ProfileFormData = z.infer<typeof profileSchema>;

export default function StudentDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch student profile
  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ['/api/student/profile'],
    queryFn: async () => {
      const response = await fetch('/api/student/profile', {
        headers: getAuthHeaders(),
      });
      if (response.status === 404) {
        return null; // No profile exists yet
      }
      if (!response.ok) {
        throw new Error('Failed to fetch profile');
      }
      return response.json();
    },
    enabled: !!user && user.role === 'student',
  });

  // Fetch student applications
  const { data: applications, isLoading: applicationsLoading } = useQuery({
    queryKey: ['/api/applications/student', user?.id],
    queryFn: async () => {
      const response = await fetch(`/api/applications/student/${user?.id}`, {
        headers: getAuthHeaders(),
      });
      if (!response.ok) {
        throw new Error('Failed to fetch applications');
      }
      return response.json();
    },
    enabled: !!user && user.role === 'student',
  });

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      bio: profile?.bio || '',
      skills: profile?.skills?.join(', ') || '',
      interests: profile?.interests?.join(', ') || '',
      education: profile?.education || '',
      experience: profile?.experience || '',
      portfolio: profile?.portfolio || '',
      resume: profile?.resume || '',
    },
  });

  // Update form when profile data loads
  useState(() => {
    if (profile) {
      form.reset({
        bio: profile.bio || '',
        skills: profile.skills?.join(', ') || '',
        interests: profile.interests?.join(', ') || '',
        education: profile.education || '',
        experience: profile.experience || '',
        portfolio: profile.portfolio || '',
        resume: profile.resume || '',
      });
    }
  });

  const profileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      const profileData = {
        ...data,
        skills: data.skills ? data.skills.split(',').map(s => s.trim()).filter(Boolean) : [],
        interests: data.interests ? data.interests.split(',').map(s => s.trim()).filter(Boolean) : [],
      };

      const method = profile ? 'PUT' : 'POST';
      const response = await apiRequest(method, '/api/student/profile', profileData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Profile updated successfully!',
        description: 'Your changes have been saved.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/student/profile'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error updating profile',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: ProfileFormData) => {
    profileMutation.mutate(data);
  };

  if (!user || user.role !== 'student') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-red-600">Access denied. Student account required.</p>
            <Link href="/">
              <Button className="mt-4">Go Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getProfileCompleteness = () => {
    if (!profile) return 20; // Just having an account
    
    let completeness = 20; // Base score
    if (profile.bio) completeness += 15;
    if (profile.skills && profile.skills.length > 0) completeness += 15;
    if (profile.interests && profile.interests.length > 0) completeness += 10;
    if (profile.education) completeness += 15;
    if (profile.experience) completeness += 10;
    if (profile.resume) completeness += 10;
    if (profile.portfolio) completeness += 5;
    
    return Math.min(completeness, 100);
  };

  const completeness = getProfileCompleteness();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Student Dashboard</h1>
          <p className="text-gray-600">Manage your profile, applications, and career progress</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <Avatar className="w-20 h-20 mx-auto mb-3">
                    <AvatarFallback className="text-2xl">
                      {user.firstName[0]}{user.lastName[0]}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="font-semibold text-gray-900">{user.firstName} {user.lastName}</h3>
                  <p className="text-sm text-gray-600">Student</p>
                </div>
                
                <nav className="space-y-2">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'overview' 
                        ? 'bg-primary text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <User className="h-4 w-4 mr-3" />
                    Overview
                  </button>
                  <button
                    onClick={() => setActiveTab('profile')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'profile' 
                        ? 'bg-primary text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <User className="h-4 w-4 mr-3" />
                    Profile
                  </button>
                  <button
                    onClick={() => setActiveTab('applications')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'applications' 
                        ? 'bg-primary text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <FileText className="h-4 w-4 mr-3" />
                    Applications
                  </button>
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center mr-3">
                          <NotebookPen className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Applications</p>
                          <p className="text-2xl font-bold text-gray-900">
                            {applications?.length || 0}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center mr-3">
                          <CheckCircle className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Interviews</p>
                          <p className="text-2xl font-bold text-gray-900">
                            {applications?.filter(app => app.status === 'interview_scheduled').length || 0}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center mr-3">
                          <Heart className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Accepted</p>
                          <p className="text-2xl font-bold text-gray-900">
                            {applications?.filter(app => app.status === 'accepted').length || 0}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-gray-600 rounded-lg flex items-center justify-center mr-3">
                          <Eye className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Profile Views</p>
                          <p className="text-2xl font-bold text-gray-900">-</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Recent Applications */}
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Applications</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {applicationsLoading ? (
                      <div className="text-center py-4">
                        <div className="loading-spinner mx-auto mb-2"></div>
                        <p className="text-gray-600">Loading applications...</p>
                      </div>
                    ) : applications && applications.length > 0 ? (
                      <div className="space-y-4">
                        {applications.slice(0, 5).map((application: StudentApplicationWithDetails) => (
                          <div key={application.id} className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center">
                              <div className="company-logo mr-3">
                                <Building className="h-5 w-5" />
                              </div>
                              <div>
                                <h4 className="font-medium text-gray-900">{application.internship.title}</h4>
                                <p className="text-sm text-gray-600">{application.internship.company.name}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge className={getStatusColor(application.status)}>
                                {getStatusText(application.status)}
                              </Badge>
                              <p className="text-xs text-gray-500 mt-1">
                                Applied {new Date(application.appliedAt).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <NotebookPen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600 mb-4">No applications yet</p>
                        <Link href="/internships">
                          <Button>Browse Internships</Button>
                        </Link>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Profile Completion */}
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Completion</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Profile completeness</span>
                        <span className="text-sm font-medium text-gray-900">{completeness}%</span>
                      </div>
                      <div className="progress-bar">
                        <div 
                          className="progress-fill" 
                          style={{ width: `${completeness}%` }}
                        ></div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center text-sm">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          <span>Basic information added</span>
                        </div>
                        <div className="flex items-center text-sm">
                          {profile?.resume ? (
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          ) : (
                            <X className="h-4 w-4 text-red-500 mr-2" />
                          )}
                          <span>Resume uploaded</span>
                        </div>
                        <div className="flex items-center text-sm">
                          {profile?.skills && profile.skills.length > 0 ? (
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          ) : (
                            <X className="h-4 w-4 text-red-500 mr-2" />
                          )}
                          <span>Add skills and interests</span>
                        </div>
                        <div className="flex items-center text-sm">
                          {profile?.portfolio ? (
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          ) : (
                            <X className="h-4 w-4 text-red-500 mr-2" />
                          )}
                          <span>Add portfolio projects</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'profile' && (
              <Card>
                <CardHeader>
                  <CardTitle>Edit Profile</CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <FormField
                        control={form.control}
                        name="bio"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Bio</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Tell us about yourself..."
                                className="min-h-[100px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="skills"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Skills (comma-separated)</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="React, JavaScript, Python..."
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="interests"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Interests (comma-separated)</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Web Development, AI, Mobile Apps..."
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="education"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Education</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Your educational background..."
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="experience"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Experience</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Your work experience and projects..."
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="resume"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Resume URL</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="https://drive.google.com/..."
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="portfolio"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Portfolio URL</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="https://yourportfolio.com"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <Button 
                        type="submit" 
                        disabled={profileMutation.isPending}
                        className="w-full md:w-auto"
                      >
                        {profileMutation.isPending ? 'Saving...' : 'Save Profile'}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            )}

            {activeTab === 'applications' && (
              <Card>
                <CardHeader>
                  <CardTitle>My Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  {applicationsLoading ? (
                    <div className="text-center py-8">
                      <div className="loading-spinner mx-auto mb-4"></div>
                      <p className="text-gray-600">Loading applications...</p>
                    </div>
                  ) : applications && applications.length > 0 ? (
                    <div className="space-y-4">
                      {applications.map((application: StudentApplicationWithDetails) => (
                        <div key={application.id} className="border rounded-lg p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex items-center">
                              <div className="company-logo mr-4">
                                <Building className="h-6 w-6" />
                              </div>
                              <div>
                                <h3 className="font-semibold text-gray-900 text-lg">
                                  {application.internship.title}
                                </h3>
                                <p className="text-gray-600">{application.internship.company.name}</p>
                              </div>
                            </div>
                            <Badge className={getStatusColor(application.status)}>
                              {getStatusText(application.status)}
                            </Badge>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <div className="flex items-center text-sm text-gray-600">
                              <MapPin className="h-4 w-4 mr-2" />
                              {application.internship.location}
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <Clock className="h-4 w-4 mr-2" />
                              {application.internship.duration}
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <Calendar className="h-4 w-4 mr-2" />
                              Applied {new Date(application.appliedAt).toLocaleDateString()}
                            </div>
                          </div>

                          {application.coverLetter && (
                            <div className="mt-4">
                              <p className="text-sm font-medium text-gray-700 mb-2">Cover Letter:</p>
                              <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
                                {application.coverLetter}
                              </p>
                            </div>
                          )}

                          <div className="mt-4 flex space-x-2">
                            <Link href={`/internships/${application.internship.id}`}>
                              <Button variant="outline" size="sm">
                                View Details
                              </Button>
                            </Link>
                            {application.resume && (
                              <a 
                                href={application.resume} 
                                target="_blank" 
                                rel="noopener noreferrer"
                              >
                                <Button variant="outline" size="sm">
                                  View Resume
                                </Button>
                              </a>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 mb-4">No applications yet</p>
                      <p className="text-gray-500 mb-6">Start your career journey by applying to internships</p>
                      <Link href="/internships">
                        <Button>Browse Internships</Button>
                      </Link>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
