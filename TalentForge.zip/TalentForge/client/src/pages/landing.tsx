import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Search, Building, TrendingUp, Users, Briefcase, Award, Quote, Star } from 'lucide-react';

export default function Landing() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="hero-gradient text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center fade-in">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Find Your <span className="text-yellow-400">Perfect</span> Internship
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              Connect with top companies and kickstart your career with meaningful internship opportunities
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
              <Link href="/internships">
                <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                  <Search className="mr-2 h-5 w-5" />
                  Find Internships
                </Button>
              </Link>
              <Link href="/signup">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                  <Building className="mr-2 h-5 w-5" />
                  Post Internships
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center stat-card p-6 rounded-lg">
                <div className="text-3xl font-bold">10,000+</div>
                <div className="text-lg opacity-90">Active Internships</div>
              </div>
              <div className="text-center stat-card p-6 rounded-lg">
                <div className="text-3xl font-bold">500+</div>
                <div className="text-lg opacity-90">Partner Companies</div>
              </div>
              <div className="text-center stat-card p-6 rounded-lg">
                <div className="text-3xl font-bold">50,000+</div>
                <div className="text-lg opacity-90">Students Placed</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose OnlyInternship.in?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We make internship hunting simple, efficient, and successful for both students and employers
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center p-6 card-hover">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">For Students</h3>
                <p className="text-gray-600">
                  Access thousands of internships, create professional profiles, and track your applications all in one place
                </p>
              </CardContent>
            </Card>
            <Card className="text-center p-6 card-hover">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Building className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">For Recruiters</h3>
                <p className="text-gray-600">
                  Post internships, find qualified candidates, and manage your hiring process with powerful tools
                </p>
              </CardContent>
            </Card>
            <Card className="text-center p-6 card-hover">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Analytics & Insights</h3>
                <p className="text-gray-600">
                  Get detailed insights about applications, success rates, and market trends to make informed decisions
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Get started with OnlyInternship.in in three simple steps
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Create Your Profile</h3>
              <p className="text-gray-600">
                Sign up and create a comprehensive profile showcasing your skills, experience, and career goals
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Browse & Apply</h3>
              <p className="text-gray-600">
                Search through thousands of internships using our advanced filters and apply with just a few clicks
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Get Hired</h3>
              <p className="text-gray-600">
                Track your applications, participate in interviews, and start your dream internship
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Success Stories Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Success Stories
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Hear from students and recruiters who found their perfect match through OnlyInternship.in
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {/* Student Success Story 1 */}
            <Card className="p-6 card-hover relative">
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-current" />
                    ))}
                  </div>
                </div>
                <Quote className="h-8 w-8 text-primary mb-4" />
                <p className="text-gray-700 mb-6 italic">
                  "I found my dream internship at Microsoft through OnlyInternship.in! The platform made it so easy to search for opportunities and the application process was seamless. Now I'm working as a full-time Software Engineer there."
                </p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    P
                  </div>
                  <div className="ml-4">
                    <div className="font-semibold text-gray-900">Priya Sharma</div>
                    <div className="text-sm text-gray-600">Software Engineer, Microsoft</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Student Success Story 2 */}
            <Card className="p-6 card-hover relative">
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-current" />
                    ))}
                  </div>
                </div>
                <Quote className="h-8 w-8 text-primary mb-4" />
                <p className="text-gray-700 mb-6 italic">
                  "The internship at Goldman Sachs I secured through this platform changed my career trajectory. The personalized dashboard helped me track all my applications and I received interview tips that made all the difference."
                </p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-teal-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    R
                  </div>
                  <div className="ml-4">
                    <div className="font-semibold text-gray-900">Rahul Gupta</div>
                    <div className="text-sm text-gray-600">Investment Analyst, Goldman Sachs</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recruiter Success Story */}
            <Card className="p-6 card-hover relative">
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-current" />
                    ))}
                  </div>
                </div>
                <Quote className="h-8 w-8 text-primary mb-4" />
                <p className="text-gray-700 mb-6 italic">
                  "OnlyInternship.in helped us find exceptional talent for our startup. The quality of candidates and the ease of managing applications made our hiring process incredibly efficient. We hired 15 interns in just 2 months!"
                </p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    A
                  </div>
                  <div className="ml-4">
                    <div className="font-semibold text-gray-900">Anita Desai</div>
                    <div className="text-sm text-gray-600">HR Director, TechStartup Inc.</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Achievement Stats */}
          <div className="bg-gray-50 rounded-2xl p-8">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                Our Impact in Numbers
              </h3>
              <p className="text-gray-600">
                Real results from our community of students and recruiters
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">94%</div>
                <div className="text-sm text-gray-600">Success Rate</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">2.5x</div>
                <div className="text-sm text-gray-600">Faster Hiring</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">₹4.2L</div>
                <div className="text-sm text-gray-600">Avg. Stipend</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">85%</div>
                <div className="text-sm text-gray-600">Full-time Offers</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Your Career Journey?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of students and companies who trust OnlyInternship.in for their internship needs
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/signup">
              <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                Get Started Now
              </Button>
            </Link>
            <Link href="/internships">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                Browse Internships
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
