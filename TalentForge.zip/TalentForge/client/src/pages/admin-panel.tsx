import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Shield, 
  Users, 
  Briefcase, 
  Building, 
  Handshake,
  UserPlus,
  TriangleAlert,
  Upload,
  BarChart,
  Settings,
  Activity,
  TrendingUp,
  Calendar,
  Eye,
  Edit,
  Trash2
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/auth';
import { getAuthHeaders } from '@/lib/auth';
import { Link } from 'wouter';

interface AdminStats {
  totalUsers: number;
  totalInternships: number;
  totalCompanies: number;
  totalApplications: number;
}

interface RecentActivity {
  id: string;
  type: 'user_registration' | 'internship_posted' | 'application_submitted' | 'report_submitted';
  description: string;
  timestamp: string;
  user?: string;
}

export default function AdminPanel() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch admin stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/admin/stats'],
    queryFn: async () => {
      const response = await fetch('/api/admin/stats', {
        headers: getAuthHeaders(),
      });
      if (!response.ok) {
        throw new Error('Failed to fetch stats');
      }
      return response.json();
    },
    enabled: !!user && user.role === 'admin',
  });

  // Fetch all users
  const { data: users, isLoading: usersLoading } = useQuery({
    queryKey: ['/api/admin/users'],
    queryFn: async () => {
      // Note: This endpoint would need to be implemented in the backend
      const response = await fetch('/api/admin/users', {
        headers: getAuthHeaders(),
      });
      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }
      return response.json();
    },
    enabled: !!user && user.role === 'admin' && activeTab === 'users',
  });

  // Fetch all internships
  const { data: internships, isLoading: internshipsLoading } = useQuery({
    queryKey: ['/api/internships'],
    queryFn: async () => {
      const response = await fetch('/api/internships');
      if (!response.ok) {
        throw new Error('Failed to fetch internships');
      }
      return response.json();
    },
    enabled: activeTab === 'internships',
  });

  // Fetch all companies
  const { data: companies, isLoading: companiesLoading } = useQuery({
    queryKey: ['/api/companies'],
    queryFn: async () => {
      const response = await fetch('/api/companies');
      if (!response.ok) {
        throw new Error('Failed to fetch companies');
      }
      return response.json();
    },
    enabled: activeTab === 'companies',
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-red-600">Access denied. Admin account required.</p>
            <Link href="/">
              <Button className="mt-4">Go Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Mock recent activity data (would come from backend)
  const recentActivities: RecentActivity[] = [
    {
      id: '1',
      type: 'user_registration',
      description: 'New user registration',
      timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
      user: 'sarah.johnson@example.com',
    },
    {
      id: '2',
      type: 'internship_posted',
      description: 'New internship posted',
      timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
      user: 'TechCorp Solutions - Frontend Developer',
    },
    {
      id: '3',
      type: 'application_submitted',
      description: 'New application submitted',
      timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
      user: 'mike.chen@example.com',
    },
    {
      id: '4',
      type: 'report_submitted',
      description: 'Content report submitted',
      timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
      user: 'Inappropriate content reported',
    },
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'user_registration':
        return <UserPlus className="h-4 w-4 text-secondary" />;
      case 'internship_posted':
        return <Briefcase className="h-4 w-4 text-primary" />;
      case 'application_submitted':
        return <Activity className="h-4 w-4 text-accent" />;
      case 'report_submitted':
        return <TriangleAlert className="h-4 w-4 text-red-500" />;
      default:
        return <Activity className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const diff = Date.now() - new Date(timestamp).getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    
    if (minutes < 60) {
      return `${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
    } else {
      return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Panel</h1>
          <p className="text-gray-600">Manage users, internships, and platform analytics</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <Avatar className="w-20 h-20 mx-auto mb-3">
                    <AvatarFallback className="text-2xl bg-red-600 text-white">
                      <Shield className="h-8 w-8" />
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="font-semibold text-gray-900">{user.firstName} {user.lastName}</h3>
                  <p className="text-sm text-gray-600">System Administrator</p>
                </div>
                
                <nav className="space-y-2">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'overview' 
                        ? 'bg-red-600 text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <BarChart className="h-4 w-4 mr-3" />
                    Dashboard
                  </button>
                  <button
                    onClick={() => setActiveTab('users')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'users' 
                        ? 'bg-red-600 text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Users className="h-4 w-4 mr-3" />
                    Users
                  </button>
                  <button
                    onClick={() => setActiveTab('internships')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'internships' 
                        ? 'bg-red-600 text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Briefcase className="h-4 w-4 mr-3" />
                    Internships
                  </button>
                  <button
                    onClick={() => setActiveTab('companies')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'companies' 
                        ? 'bg-red-600 text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Building className="h-4 w-4 mr-3" />
                    Companies
                  </button>
                  <button
                    onClick={() => setActiveTab('analytics')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'analytics' 
                        ? 'bg-red-600 text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <TrendingUp className="h-4 w-4 mr-3" />
                    Analytics
                  </button>
                  <button
                    onClick={() => setActiveTab('settings')}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'settings' 
                        ? 'bg-red-600 text-white' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Settings className="h-4 w-4 mr-3" />
                    Settings
                  </button>
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Admin Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                          <Users className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Total Users</p>
                          <p className="text-2xl font-bold text-gray-900">
                            {statsLoading ? '-' : stats?.totalUsers?.toLocaleString() || '0'}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center mr-3">
                          <Briefcase className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Active Internships</p>
                          <p className="text-2xl font-bold text-gray-900">
                            {statsLoading ? '-' : stats?.totalInternships?.toLocaleString() || '0'}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center mr-3">
                          <Building className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Companies</p>
                          <p className="text-2xl font-bold text-gray-900">
                            {statsLoading ? '-' : stats?.totalCompanies?.toLocaleString() || '0'}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center mr-3">
                          <Handshake className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Total Applications</p>
                          <p className="text-2xl font-bold text-gray-900">
                            {statsLoading ? '-' : stats?.totalApplications?.toLocaleString() || '0'}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Recent Activity */}
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentActivities.map((activity) => (
                        <div key={activity.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center">
                            <div className="w-8 h-8 rounded-full flex items-center justify-center bg-white mr-3">
                              {getActivityIcon(activity.type)}
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-900">{activity.description}</p>
                              <p className="text-xs text-gray-500">{activity.user}</p>
                            </div>
                          </div>
                          <span className="text-xs text-gray-500">{formatTimeAgo(activity.timestamp)}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Management Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Management Actions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button className="bg-primary text-white p-4 h-auto flex-col items-start text-left">
                        <Upload className="h-6 w-6 mb-2" />
                        <div className="font-medium">Bulk Upload Internships</div>
                        <div className="text-sm opacity-90">Upload multiple internships via CSV</div>
                      </Button>
                      <Button 
                        variant="outline" 
                        className="p-4 h-auto flex-col items-start text-left"
                        onClick={() => setActiveTab('users')}
                      >
                        <Shield className="h-6 w-6 mb-2" />
                        <div className="font-medium">User Management</div>
                        <div className="text-sm text-gray-600">Manage user accounts and permissions</div>
                      </Button>
                      <Button 
                        variant="outline" 
                        className="p-4 h-auto flex-col items-start text-left"
                        onClick={() => setActiveTab('analytics')}
                      >
                        <BarChart className="h-6 w-6 mb-2" />
                        <div className="font-medium">Generate Reports</div>
                        <div className="text-sm text-gray-600">Create detailed analytics reports</div>
                      </Button>
                      <Button 
                        variant="outline" 
                        className="p-4 h-auto flex-col items-start text-left"
                        onClick={() => setActiveTab('settings')}
                      >
                        <Settings className="h-6 w-6 mb-2" />
                        <div className="font-medium">System Settings</div>
                        <div className="text-sm text-gray-600">Configure platform settings</div>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'users' && (
              <Card>
                <CardHeader>
                  <CardTitle>User Management</CardTitle>
                </CardHeader>
                <CardContent>
                  {usersLoading ? (
                    <div className="text-center py-8">
                      <div className="loading-spinner mx-auto mb-4"></div>
                      <p className="text-gray-600">Loading users...</p>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 mb-4">User management interface</p>
                      <p className="text-gray-500">This feature would allow admins to view, edit, and manage user accounts</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {activeTab === 'internships' && (
              <Card>
                <CardHeader>
                  <CardTitle>Internship Management</CardTitle>
                </CardHeader>
                <CardContent>
                  {internshipsLoading ? (
                    <div className="text-center py-8">
                      <div className="loading-spinner mx-auto mb-4"></div>
                      <p className="text-gray-600">Loading internships...</p>
                    </div>
                  ) : internships && internships.length > 0 ? (
                    <div className="space-y-4">
                      {internships.slice(0, 10).map((internship: any) => (
                        <div key={internship.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <h3 className="font-medium text-gray-900">{internship.title}</h3>
                            <p className="text-sm text-gray-600">{internship.company.name}</p>
                            <p className="text-xs text-gray-500">
                              Posted {new Date(internship.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant={internship.isActive ? 'default' : 'secondary'}>
                              {internship.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Briefcase className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No internships found</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {activeTab === 'companies' && (
              <Card>
                <CardHeader>
                  <CardTitle>Company Management</CardTitle>
                </CardHeader>
                <CardContent>
                  {companiesLoading ? (
                    <div className="text-center py-8">
                      <div className="loading-spinner mx-auto mb-4"></div>
                      <p className="text-gray-600">Loading companies...</p>
                    </div>
                  ) : companies && companies.length > 0 ? (
                    <div className="space-y-4">
                      {companies.map((company: any) => (
                        <div key={company.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <h3 className="font-medium text-gray-900">{company.name}</h3>
                            <p className="text-sm text-gray-600">{company.industry}</p>
                            <p className="text-xs text-gray-500">{company.size}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Building className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No companies found</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {activeTab === 'analytics' && (
              <Card>
                <CardHeader>
                  <CardTitle>Analytics & Reports</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <TrendingUp className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-4">Advanced Analytics Dashboard</p>
                    <p className="text-gray-500">This section would contain detailed charts, graphs, and metrics about platform usage</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'settings' && (
              <Card>
                <CardHeader>
                  <CardTitle>System Settings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <Settings className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-4">System Configuration</p>
                    <p className="text-gray-500">Platform settings, configurations, and system preferences would be managed here</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
