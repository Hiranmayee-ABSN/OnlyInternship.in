import { useParams } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, MapPin, Clock, DollarSign, Calendar, Building, Globe, Users, Code } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Link } from 'wouter';
import ApplicationForm from '@/components/application-form';
import { InternshipWithDetails, getTypeColor, getTypeText } from '@/lib/types';

export default function InternshipDetail() {
  const { id } = useParams();

  const { data: internship, isLoading, error } = useQuery({
    queryKey: [`/api/internships/${id}`],
    queryFn: async () => {
      const response = await fetch(`/api/internships/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch internship details');
      }
      return response.json();
    },
    enabled: !!id,
  });

  const formatStipend = (min?: string, max?: string) => {
    if (!min && !max) return 'Stipend not specified';
    if (min && max) return `₹${min} - ₹${max}/month`;
    if (min) return `₹${min}/month`;
    return `₹${max}/month`;
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="loading-spinner mx-auto mb-4"></div>
          <p className="text-gray-600">Loading internship details...</p>
        </div>
      </div>
    );
  }

  if (error || !internship) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-red-600 mb-4">Error loading internship details</p>
            <Link href="/internships">
              <Button>Back to Internships</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-6">
          <Link href="/internships">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Internships
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Internship Header */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center">
                    <div className="company-logo mr-4">
                      <Code className="h-8 w-8" />
                    </div>
                    <div>
                      <h1 className="text-3xl font-bold text-gray-900 mb-2">
                        {internship.title}
                      </h1>
                      <p className="text-xl text-gray-600">{internship.company.name}</p>
                      <div className="flex items-center mt-2 space-x-3">
                        <Badge className={getTypeColor(internship.type)}>
                          {getTypeText(internship.type)}
                        </Badge>
                        <Badge variant="outline">
                          {internship.domain}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          Posted {formatDate(internship.createdAt)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Job Description */}
            <Card>
              <CardHeader>
                <CardTitle>Job Description</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none">
                  <p className="text-gray-700 whitespace-pre-line">
                    {internship.description}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Requirements */}
            <Card>
              <CardHeader>
                <CardTitle>Requirements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none">
                  <p className="text-gray-700 whitespace-pre-line">
                    {internship.requirements}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Skills & Technologies */}
            {internship.skills && internship.skills.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Skills & Technologies</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {internship.skills.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="skill-tag">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Internship Details */}
            <Card>
              <CardHeader>
                <CardTitle>Internship Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-gray-500 mr-3" />
                  <span className="text-gray-700">{internship.location}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-gray-500 mr-3" />
                  <span className="text-gray-700">{internship.duration}</span>
                </div>
                <div className="flex items-center">
                  <DollarSign className="h-5 w-5 text-gray-500 mr-3" />
                  <span className="text-gray-700">
                    {formatStipend(internship.stipendMin, internship.stipendMax)}
                  </span>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-gray-500 mr-3" />
                  <span className="text-gray-700">Start Date: Immediate</span>
                </div>
              </CardContent>
            </Card>

            {/* Company Info */}
            <Card>
              <CardHeader>
                <CardTitle>Company Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <h4 className="font-semibold text-gray-900">{internship.company.name}</h4>
                {internship.company.description && (
                  <p className="text-sm text-gray-700">{internship.company.description}</p>
                )}
                {internship.company.size && (
                  <div className="flex items-center text-sm text-gray-600">
                    <Users className="h-4 w-4 mr-2" />
                    <span>{internship.company.size}</span>
                  </div>
                )}
                {internship.company.website && (
                  <div className="flex items-center text-sm text-gray-600">
                    <Globe className="h-4 w-4 mr-2" />
                    <a 
                      href={internship.company.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                    >
                      {internship.company.website}
                    </a>
                  </div>
                )}
                {internship.company.industry && (
                  <div className="flex items-center text-sm text-gray-600">
                    <Building className="h-4 w-4 mr-2" />
                    <span>{internship.company.industry}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Application Form */}
            <ApplicationForm 
              internship={internship} 
              onSuccess={() => {
                // Could redirect to applications page or show success message
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
