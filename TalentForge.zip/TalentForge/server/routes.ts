import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { insertUserSchema, insertCompanySchema, insertInternshipSchema, insertStudentProfileSchema, insertApplicationSchema } from "@shared/schema";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Authentication middleware
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Role-based access control
const requireRole = (roles: string[]) => {
  return (req: any, res: any, next: any) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    next();
  };
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 10);
      
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
      });

      // Generate JWT token
      const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.status(201).json({
        message: "User created successfully",
        token,
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        },
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ message: "Invalid registration data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.json({
        message: "Login successful",
        token,
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        },
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // User profile routes
  app.get("/api/user/profile", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
      });
    } catch (error) {
      console.error("Profile fetch error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Company routes
  app.get("/api/companies", async (req, res) => {
    try {
      const companies = await storage.getCompanies();
      res.json(companies);
    } catch (error) {
      console.error("Companies fetch error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/companies", authenticateToken, requireRole(['admin', 'recruiter']), async (req: any, res) => {
    try {
      const validatedData = insertCompanySchema.parse(req.body);
      const company = await storage.createCompany(validatedData);
      res.status(201).json(company);
    } catch (error) {
      console.error("Company creation error:", error);
      res.status(400).json({ message: "Invalid company data" });
    }
  });

  // Internship routes
  app.get("/api/internships", async (req, res) => {
    try {
      const { search, domain, location, type, duration, limit, offset } = req.query;
      const internships = await storage.getInternships({
        search: search as string,
        domain: domain as string,
        location: location as string,
        type: type as string,
        duration: duration as string,
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
      });
      res.json(internships);
    } catch (error) {
      console.error("Internships fetch error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/internships/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const internship = await storage.getInternship(id);
      if (!internship) {
        return res.status(404).json({ message: "Internship not found" });
      }
      res.json(internship);
    } catch (error) {
      console.error("Internship fetch error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/internships", authenticateToken, requireRole(['admin', 'recruiter']), async (req: any, res) => {
    try {
      const validatedData = insertInternshipSchema.parse(req.body);
      const internship = await storage.createInternship({
        ...validatedData,
        recruiterId: req.user.id,
      });
      res.status(201).json(internship);
    } catch (error) {
      console.error("Internship creation error:", error);
      res.status(400).json({ message: "Invalid internship data" });
    }
  });

  app.put("/api/internships/:id", authenticateToken, requireRole(['admin', 'recruiter']), async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertInternshipSchema.partial().parse(req.body);
      
      // Check if user owns this internship (unless admin)
      if (req.user.role !== 'admin') {
        const existingInternship = await storage.getInternship(id);
        if (!existingInternship || existingInternship.recruiterId !== req.user.id) {
          return res.status(403).json({ message: "Not authorized to update this internship" });
        }
      }
      
      const internship = await storage.updateInternship(id, validatedData);
      res.json(internship);
    } catch (error) {
      console.error("Internship update error:", error);
      res.status(400).json({ message: "Invalid internship data" });
    }
  });

  app.delete("/api/internships/:id", authenticateToken, requireRole(['admin', 'recruiter']), async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Check if user owns this internship (unless admin)
      if (req.user.role !== 'admin') {
        const existingInternship = await storage.getInternship(id);
        if (!existingInternship || existingInternship.recruiterId !== req.user.id) {
          return res.status(403).json({ message: "Not authorized to delete this internship" });
        }
      }
      
      await storage.deleteInternship(id);
      res.json({ message: "Internship deleted successfully" });
    } catch (error) {
      console.error("Internship deletion error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/internships/recruiter/:recruiterId", authenticateToken, async (req: any, res) => {
    try {
      const recruiterId = parseInt(req.params.recruiterId);
      
      // Check if user is requesting their own internships or is admin
      if (req.user.id !== recruiterId && req.user.role !== 'admin') {
        return res.status(403).json({ message: "Not authorized to view these internships" });
      }
      
      const internships = await storage.getInternshipsByRecruiter(recruiterId);
      res.json(internships);
    } catch (error) {
      console.error("Recruiter internships fetch error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Student profile routes
  app.get("/api/student/profile", authenticateToken, requireRole(['student']), async (req: any, res) => {
    try {
      const profile = await storage.getStudentProfile(req.user.id);
      res.json(profile);
    } catch (error) {
      console.error("Student profile fetch error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/student/profile", authenticateToken, requireRole(['student']), async (req: any, res) => {
    try {
      const validatedData = insertStudentProfileSchema.parse(req.body);
      const profile = await storage.createStudentProfile({
        ...validatedData,
        userId: req.user.id,
      });
      res.status(201).json(profile);
    } catch (error) {
      console.error("Student profile creation error:", error);
      res.status(400).json({ message: "Invalid profile data" });
    }
  });

  app.put("/api/student/profile", authenticateToken, requireRole(['student']), async (req: any, res) => {
    try {
      const validatedData = insertStudentProfileSchema.partial().parse(req.body);
      const profile = await storage.updateStudentProfile(req.user.id, validatedData);
      res.json(profile);
    } catch (error) {
      console.error("Student profile update error:", error);
      res.status(400).json({ message: "Invalid profile data" });
    }
  });

  // Application routes
  app.get("/api/applications", authenticateToken, async (req: any, res) => {
    try {
      const { studentId, internshipId, status } = req.query;
      
      // Students can only see their own applications
      if (req.user.role === 'student' && studentId && parseInt(studentId as string) !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to view these applications" });
      }
      
      const applications = await storage.getApplications({
        studentId: studentId ? parseInt(studentId as string) : undefined,
        internshipId: internshipId ? parseInt(internshipId as string) : undefined,
        status: status as string,
      });
      
      res.json(applications);
    } catch (error) {
      console.error("Applications fetch error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/applications", authenticateToken, requireRole(['student']), async (req: any, res) => {
    try {
      const validatedData = insertApplicationSchema.parse(req.body);
      const application = await storage.createApplication({
        ...validatedData,
        studentId: req.user.id,
      });
      res.status(201).json(application);
    } catch (error) {
      console.error("Application creation error:", error);
      res.status(400).json({ message: "Invalid application data" });
    }
  });

  app.put("/api/applications/:id", authenticateToken, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertApplicationSchema.partial().parse(req.body);
      
      // Check permissions
      const existingApplication = await storage.getApplication(id);
      if (!existingApplication) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      // Students can only update their own applications, recruiters can update applications for their internships
      if (req.user.role === 'student' && existingApplication.studentId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to update this application" });
      }
      
      if (req.user.role === 'recruiter' && existingApplication.internship.recruiterId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to update this application" });
      }
      
      const application = await storage.updateApplication(id, validatedData);
      res.json(application);
    } catch (error) {
      console.error("Application update error:", error);
      res.status(400).json({ message: "Invalid application data" });
    }
  });

  app.get("/api/applications/student/:studentId", authenticateToken, async (req: any, res) => {
    try {
      const studentId = parseInt(req.params.studentId);
      
      // Check if user is requesting their own applications or is admin
      if (req.user.id !== studentId && req.user.role !== 'admin') {
        return res.status(403).json({ message: "Not authorized to view these applications" });
      }
      
      const applications = await storage.getApplicationsByStudent(studentId);
      res.json(applications);
    } catch (error) {
      console.error("Student applications fetch error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/applications/internship/:internshipId", authenticateToken, requireRole(['admin', 'recruiter']), async (req: any, res) => {
    try {
      const internshipId = parseInt(req.params.internshipId);
      
      // Check if recruiter owns this internship
      if (req.user.role === 'recruiter') {
        const internship = await storage.getInternship(internshipId);
        if (!internship || internship.recruiterId !== req.user.id) {
          return res.status(403).json({ message: "Not authorized to view these applications" });
        }
      }
      
      const applications = await storage.getApplicationsByInternship(internshipId);
      res.json(applications);
    } catch (error) {
      console.error("Internship applications fetch error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin routes
  app.get("/api/admin/stats", authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      console.error("Stats fetch error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
