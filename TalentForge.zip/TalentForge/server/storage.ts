import { 
  users, 
  companies, 
  internships, 
  studentProfiles, 
  applications,
  type User, 
  type InsertUser,
  type Company,
  type InsertCompany,
  type Internship,
  type InsertInternship,
  type StudentProfile,
  type InsertStudentProfile,
  type Application,
  type InsertApplication
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, ilike, or, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User>;
  
  // Company operations
  getCompany(id: number): Promise<Company | undefined>;
  getCompanies(): Promise<Company[]>;
  createCompany(company: InsertCompany): Promise<Company>;
  updateCompany(id: number, company: Partial<InsertCompany>): Promise<Company>;
  
  // Internship operations
  getInternship(id: number): Promise<(Internship & { company: Company; recruiter: User }) | undefined>;
  getInternships(filters?: {
    search?: string;
    domain?: string;
    location?: string;
    type?: string;
    duration?: string;
    limit?: number;
    offset?: number;
  }): Promise<(Internship & { company: Company; recruiter: User })[]>;
  createInternship(internship: InsertInternship): Promise<Internship>;
  updateInternship(id: number, internship: Partial<InsertInternship>): Promise<Internship>;
  deleteInternship(id: number): Promise<void>;
  getInternshipsByRecruiter(recruiterId: number): Promise<(Internship & { company: Company })[]>;
  
  // Student profile operations
  getStudentProfile(userId: number): Promise<StudentProfile | undefined>;
  createStudentProfile(profile: InsertStudentProfile): Promise<StudentProfile>;
  updateStudentProfile(userId: number, profile: Partial<InsertStudentProfile>): Promise<StudentProfile>;
  
  // Application operations
  getApplication(id: number): Promise<(Application & { student: User; internship: Internship & { company: Company } }) | undefined>;
  getApplications(filters?: {
    studentId?: number;
    internshipId?: number;
    status?: string;
  }): Promise<(Application & { student: User; internship: Internship & { company: Company } })[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplication(id: number, application: Partial<InsertApplication>): Promise<Application>;
  getApplicationsByStudent(studentId: number): Promise<(Application & { internship: Internship & { company: Company } })[]>;
  getApplicationsByInternship(internshipId: number): Promise<(Application & { student: User })[]>;
  
  // Stats operations
  getStats(): Promise<{
    totalUsers: number;
    totalInternships: number;
    totalCompanies: number;
    totalApplications: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        updatedAt: new Date(),
      })
      .returning();
    return user;
  }

  async updateUser(id: number, updateUser: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...updateUser,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getCompany(id: number): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.id, id));
    return company || undefined;
  }

  async getCompanies(): Promise<Company[]> {
    return await db.select().from(companies).orderBy(desc(companies.createdAt));
  }

  async createCompany(insertCompany: InsertCompany): Promise<Company> {
    const [company] = await db
      .insert(companies)
      .values({
        ...insertCompany,
        updatedAt: new Date(),
      })
      .returning();
    return company;
  }

  async updateCompany(id: number, updateCompany: Partial<InsertCompany>): Promise<Company> {
    const [company] = await db
      .update(companies)
      .set({
        ...updateCompany,
        updatedAt: new Date(),
      })
      .where(eq(companies.id, id))
      .returning();
    return company;
  }

  async getInternship(id: number): Promise<(Internship & { company: Company; recruiter: User }) | undefined> {
    const [result] = await db
      .select()
      .from(internships)
      .leftJoin(companies, eq(internships.companyId, companies.id))
      .leftJoin(users, eq(internships.recruiterId, users.id))
      .where(eq(internships.id, id));
    
    if (!result?.internships || !result?.companies || !result?.users) {
      return undefined;
    }
    
    return {
      ...result.internships,
      company: result.companies,
      recruiter: result.users,
    };
  }

  async getInternships(filters?: {
    search?: string;
    domain?: string;
    location?: string;
    type?: string;
    duration?: string;
    limit?: number;
    offset?: number;
  }): Promise<(Internship & { company: Company; recruiter: User })[]> {
    let query = db
      .select()
      .from(internships)
      .leftJoin(companies, eq(internships.companyId, companies.id))
      .leftJoin(users, eq(internships.recruiterId, users.id))
      .where(eq(internships.isActive, true));

    if (filters?.search) {
      query = query.where(
        or(
          ilike(internships.title, `%${filters.search}%`),
          ilike(internships.description, `%${filters.search}%`)
        )
      );
    }

    if (filters?.domain) {
      query = query.where(eq(internships.domain, filters.domain));
    }

    if (filters?.location) {
      query = query.where(ilike(internships.location, `%${filters.location}%`));
    }

    if (filters?.type) {
      query = query.where(eq(internships.type, filters.type as any));
    }

    if (filters?.duration) {
      query = query.where(eq(internships.duration, filters.duration));
    }

    query = query.orderBy(desc(internships.createdAt));

    if (filters?.limit) {
      query = query.limit(filters.limit);
    }

    if (filters?.offset) {
      query = query.offset(filters.offset);
    }

    const results = await query;
    
    return results
      .filter(result => result.internships && result.companies && result.users)
      .map(result => ({
        ...result.internships!,
        company: result.companies!,
        recruiter: result.users!,
      }));
  }

  async createInternship(insertInternship: InsertInternship): Promise<Internship> {
    const [internship] = await db
      .insert(internships)
      .values({
        ...insertInternship,
        updatedAt: new Date(),
      })
      .returning();
    return internship;
  }

  async updateInternship(id: number, updateInternship: Partial<InsertInternship>): Promise<Internship> {
    const [internship] = await db
      .update(internships)
      .set({
        ...updateInternship,
        updatedAt: new Date(),
      })
      .where(eq(internships.id, id))
      .returning();
    return internship;
  }

  async deleteInternship(id: number): Promise<void> {
    await db.delete(internships).where(eq(internships.id, id));
  }

  async getInternshipsByRecruiter(recruiterId: number): Promise<(Internship & { company: Company })[]> {
    const results = await db
      .select()
      .from(internships)
      .leftJoin(companies, eq(internships.companyId, companies.id))
      .where(eq(internships.recruiterId, recruiterId))
      .orderBy(desc(internships.createdAt));
    
    return results
      .filter(result => result.internships && result.companies)
      .map(result => ({
        ...result.internships!,
        company: result.companies!,
      }));
  }

  async getStudentProfile(userId: number): Promise<StudentProfile | undefined> {
    const [profile] = await db.select().from(studentProfiles).where(eq(studentProfiles.userId, userId));
    return profile || undefined;
  }

  async createStudentProfile(insertProfile: InsertStudentProfile): Promise<StudentProfile> {
    const [profile] = await db
      .insert(studentProfiles)
      .values({
        ...insertProfile,
        updatedAt: new Date(),
      })
      .returning();
    return profile;
  }

  async updateStudentProfile(userId: number, updateProfile: Partial<InsertStudentProfile>): Promise<StudentProfile> {
    const [profile] = await db
      .update(studentProfiles)
      .set({
        ...updateProfile,
        updatedAt: new Date(),
      })
      .where(eq(studentProfiles.userId, userId))
      .returning();
    return profile;
  }

  async getApplication(id: number): Promise<(Application & { student: User; internship: Internship & { company: Company } }) | undefined> {
    const [result] = await db
      .select()
      .from(applications)
      .leftJoin(users, eq(applications.studentId, users.id))
      .leftJoin(internships, eq(applications.internshipId, internships.id))
      .leftJoin(companies, eq(internships.companyId, companies.id))
      .where(eq(applications.id, id));
    
    if (!result?.applications || !result?.users || !result?.internships || !result?.companies) {
      return undefined;
    }
    
    return {
      ...result.applications,
      student: result.users,
      internship: {
        ...result.internships,
        company: result.companies,
      },
    };
  }

  async getApplications(filters?: {
    studentId?: number;
    internshipId?: number;
    status?: string;
  }): Promise<(Application & { student: User; internship: Internship & { company: Company } })[]> {
    let query = db
      .select()
      .from(applications)
      .leftJoin(users, eq(applications.studentId, users.id))
      .leftJoin(internships, eq(applications.internshipId, internships.id))
      .leftJoin(companies, eq(internships.companyId, companies.id));

    const conditions = [];
    
    if (filters?.studentId) {
      conditions.push(eq(applications.studentId, filters.studentId));
    }
    
    if (filters?.internshipId) {
      conditions.push(eq(applications.internshipId, filters.internshipId));
    }
    
    if (filters?.status) {
      conditions.push(eq(applications.status, filters.status as any));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    query = query.orderBy(desc(applications.appliedAt));

    const results = await query;
    
    return results
      .filter(result => result.applications && result.users && result.internships && result.companies)
      .map(result => ({
        ...result.applications!,
        student: result.users!,
        internship: {
          ...result.internships!,
          company: result.companies!,
        },
      }));
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const [application] = await db
      .insert(applications)
      .values({
        ...insertApplication,
        updatedAt: new Date(),
      })
      .returning();
    return application;
  }

  async updateApplication(id: number, updateApplication: Partial<InsertApplication>): Promise<Application> {
    const [application] = await db
      .update(applications)
      .set({
        ...updateApplication,
        updatedAt: new Date(),
      })
      .where(eq(applications.id, id))
      .returning();
    return application;
  }

  async getApplicationsByStudent(studentId: number): Promise<(Application & { internship: Internship & { company: Company } })[]> {
    const results = await db
      .select()
      .from(applications)
      .leftJoin(internships, eq(applications.internshipId, internships.id))
      .leftJoin(companies, eq(internships.companyId, companies.id))
      .where(eq(applications.studentId, studentId))
      .orderBy(desc(applications.appliedAt));
    
    return results
      .filter(result => result.applications && result.internships && result.companies)
      .map(result => ({
        ...result.applications!,
        internship: {
          ...result.internships!,
          company: result.companies!,
        },
      }));
  }

  async getApplicationsByInternship(internshipId: number): Promise<(Application & { student: User })[]> {
    const results = await db
      .select()
      .from(applications)
      .leftJoin(users, eq(applications.studentId, users.id))
      .where(eq(applications.internshipId, internshipId))
      .orderBy(desc(applications.appliedAt));
    
    return results
      .filter(result => result.applications && result.users)
      .map(result => ({
        ...result.applications!,
        student: result.users!,
      }));
  }

  async getStats(): Promise<{
    totalUsers: number;
    totalInternships: number;
    totalCompanies: number;
    totalApplications: number;
  }> {
    const [userCount] = await db.select({ count: users.id }).from(users);
    const [internshipCount] = await db.select({ count: internships.id }).from(internships);
    const [companyCount] = await db.select({ count: companies.id }).from(companies);
    const [applicationCount] = await db.select({ count: applications.id }).from(applications);

    return {
      totalUsers: userCount?.count || 0,
      totalInternships: internshipCount?.count || 0,
      totalCompanies: companyCount?.count || 0,
      totalApplications: applicationCount?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
