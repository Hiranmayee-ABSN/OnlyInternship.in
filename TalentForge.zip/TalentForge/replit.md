# OnlyInternship.in - Replit Configuration

## Overview

OnlyInternship.in is a full-stack web application that connects students with internship opportunities. The platform serves as a marketplace where students can browse and apply for internships, while recruiters can post opportunities and manage applications. The application includes comprehensive admin functionality for platform management.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **Authentication**: Context-based authentication with JWT tokens
- **UI Components**: Radix UI primitives with shadcn/ui components
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite for development and build processes

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Neon serverless database
- **ORM**: Drizzle ORM for database operations and migrations
- **Authentication**: JWT-based authentication with bcrypt for password hashing
- **API Design**: RESTful API with role-based access control
- **Development**: Hot module replacement and development server integration

## Key Components

### User Management
- **Multi-role System**: Students, recruiters, and admins with different permissions
- **Authentication**: Email/password login with JWT token management
- **Profile Management**: Role-specific profile creation and updates
- **Session Management**: Secure token storage and validation

### Internship Management
- **CRUD Operations**: Full internship lifecycle management
- **Advanced Filtering**: Search by domain, location, type, duration, and stipend
- **Application System**: Students can apply with cover letters and resumes
- **Status Tracking**: Application status management (pending, under review, etc.)

### Database Schema
- **Users Table**: Core user information with role-based access
- **Companies Table**: Company profiles and information
- **Internships Table**: Internship postings with detailed requirements
- **Student Profiles**: Extended student information and portfolios
- **Applications Table**: Application tracking and management

### Admin Panel
- **User Management**: View and manage all platform users
- **Content Moderation**: Oversee internship postings and applications
- **Analytics**: Platform statistics and usage metrics
- **System Administration**: Platform configuration and maintenance

## Data Flow

1. **User Registration/Login**: JWT token generation and storage
2. **Internship Discovery**: Filtered search results with pagination
3. **Application Process**: Student applies → Recruiter reviews → Status updates
4. **Dashboard Updates**: Real-time data synchronization via TanStack Query
5. **Admin Operations**: Centralized management of all platform data

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Neon PostgreSQL database connection
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/react-***: Accessible UI component primitives
- **drizzle-orm**: Type-safe database operations
- **bcryptjs**: Password hashing and validation
- **jsonwebtoken**: JWT token creation and verification
- **zod**: Runtime type validation and schema parsing

### Development Dependencies
- **vite**: Build tool and development server
- **typescript**: Type checking and development
- **tailwindcss**: Utility-first CSS framework
- **@replit/vite-plugin-***: Replit-specific development tools

## Deployment Strategy

### Build Process
1. **Client Build**: Vite builds React application to `dist/public`
2. **Server Build**: ESBuild bundles Express server to `dist/index.js`
3. **Database Migration**: Drizzle handles schema migrations
4. **Environment Variables**: Database URL and JWT secret configuration

### Production Configuration
- **Server**: Express serves both API and static files
- **Database**: Neon PostgreSQL with connection pooling
- **Authentication**: Secure JWT implementation with environment-based secrets
- **File Serving**: Static file serving for production builds

### Environment Setup
- **Development**: Local development with hot reloading
- **Database**: Neon serverless PostgreSQL instance
- **Secrets**: Environment variables for database URL and JWT secret

## Changelog

```
Changelog:
- July 03, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```